<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="Tileset_2" tilewidth="16" tileheight="16" tilecount="24" columns="6">
 <image source="images/0_Template_Tileset1_A.png" width="96" height="64"/>
</tileset>
